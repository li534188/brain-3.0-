
export interface StoreState {
    languageName: string;
    enthusiasmLevel: number;
}

