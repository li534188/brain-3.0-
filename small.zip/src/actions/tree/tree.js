import {SHOW} from '../../constants/tree/tree'

export const show = () => {
    return {
      type: SHOW
    }
  }