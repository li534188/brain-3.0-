import { combineReducers } from 'redux'
import parents from './counter'

export default combineReducers({
    parents
})